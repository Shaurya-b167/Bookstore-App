package lab;

/**
 * Name: Shaurya Beriwala
 * Username: beris01
 */

public class Book {
	private String name;
	private double price;
	
	public Book(String name, double price) {
		this.name= name;
		this.price= price;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}
}
